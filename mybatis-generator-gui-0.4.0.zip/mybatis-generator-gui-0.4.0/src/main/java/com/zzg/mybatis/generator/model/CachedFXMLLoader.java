package com.zzg.mybatis.generator.model;

public class CachedFXMLLoader {

}
